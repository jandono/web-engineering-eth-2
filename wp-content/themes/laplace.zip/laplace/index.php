<?php /*get_header(); */?>
<?php /*get_template_part( 'content', get_post_type() );*/ ?>
<?php /*get_footer(); */?> 
