<?php

add_theme_support('post-thumbnails');

function laplace_scripts() {
	wp_enqueue_style( 'laplace', get_template_directory_uri() . '/css/stylesheet.css' );
    
    wp_enqueue_style( 'kreon', "https://fonts.googleapis.com/css?family=Kreon");
    
    wp_enqueue_style( 'roboto', "https://fonts.googleapis.com/css?family=Roboto:100,700");
    
	wp_enqueue_script( 'jquery-viewport', get_template_directory_uri() . '/js/jquery.viewport.js', array('jquery'), '3.2.0', false);
    
    wp_enqueue_script( 'main-js', get_template_directory_uri() . '/js/script.js', array('jquery'), '3.2.0', false);
}

add_action( 'wp_enqueue_scripts', 'laplace_scripts' );

function my_enqueue() {
    wp_enqueue_script( 'my_custom_script',  get_template_directory_uri() . '/js/date_picker.js' );
}

add_action('admin_enqueue_scripts', 'my_enqueue');

function create_menu_item() {
	register_post_type( 'menu-item',
			array(
			'labels' => array(
					'name' => __( 'Menu Item' ),
					'singular_name' => __( 'Menu Item' ),
			),
			'public' => true,
			'has_archive' => true,
			'supports' => array(
					'title',
					'editor',
                    'thumbnail',
				    'custom-fields'
			)
	));
}
add_action( 'init', 'create_menu_item' );

function create_event_item() {
	register_post_type( 'event-item',
			array(
			'labels' => array(
					'name' => __( 'Event Item' ),
					'singular_name' => __( 'Event Item' ),
			),
			'public' => true,
			'has_archive' => true,
			'supports' => array(
					'title',
					'editor',
                    'thumbnail',
				    'custom-fields'
			)
	));
}
add_action( 'init', 'create_event_item' );

function wpdocs_custom_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'wpdocs_custom_excerpt_length', 999 );

//function wpdocs_excerpt_more( $more ) {
//    return sprintf( '<a class="read-more" href="%1$s">%2$s</a>',
//        get_permalink( get_the_ID() ),
//        __( 'Read More', 'textdomain' )
//    );
//}
//add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );

function wpdocs_excerpt_more( $more ) {
    return '<span id="' . get_the_ID() . '" class="read-more"> [Read More]</a>';
}
add_filter( 'excerpt_more', 'wpdocs_excerpt_more' );


//AJAX
add_action( 'wp_ajax_nopriv_get_events_after_date', 'get_events_after_date' );
add_action( 'wp_ajax_get_events_after_date', 'get_events_after_date' );

function get_events_after_date(){
    $date_from = $_POST['date_from'];
    date_default_timezone_set('Europe/Skopje');
    
    $args = array(
        'post_type' => 'event-item',
        'posts_per_page' => 4,
        'order' => 'desc',
        'meta_key' => 'date_from',
        'orderby' => 'meta_value',
        'meta_query' => array(
            array(
                'key' => 'date_from',
                'value' => $date_from,
                'compare' => '<'
            )
        )
    );

    $the_query = new WP_Query( $args );
    
    if ( $the_query->have_posts() ) {
        while ( $the_query->have_posts() ) {
            $the_query->the_post();
            get_template_part( 'content-past', get_post_type() );
        }
        /* Restore original Post Data */
        wp_reset_postdata(); 
    } else {
    // no posts found
    }   
    
    //echo $_POST['date_from'];
    wp_die();
}

add_action( 'wp_ajax_nopriv_get_event_info', 'get_event_info' );
add_action( 'wp_ajax_get_event_info', 'get_event_info' );

function get_event_info(){
    $post_id = $_POST['id'];
    
    $args = array(
        'post_type' => 'event-item',
        'posts_per_page' => 1,
        'p' => $post_id
    );

    $the_query = new WP_Query( $args );
    
    if ( $the_query->have_posts() ) {
        while ( $the_query->have_posts() ) {
            $the_query->the_post();
            get_template_part( 'content-single', get_post_type() );
        }
        /* Restore original Post Data */
        wp_reset_postdata(); 
    } else {
    // no posts found
    } 
    
    wp_die();
}